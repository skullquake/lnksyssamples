ace.define("ace/snippets/eiffel",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="eiffel"});
                (function() {
                    ace.require(["ace/snippets/eiffel"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            