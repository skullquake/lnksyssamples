ace.define("ace/snippets/twig",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="twig"});
                (function() {
                    ace.require(["ace/snippets/twig"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            