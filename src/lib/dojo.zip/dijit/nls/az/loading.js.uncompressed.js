define(
"dijit/nls/az/loading", ({
	"loadingState" : "Yüklənir...",
	"errorState" : "Problem yarandı"
})
);
