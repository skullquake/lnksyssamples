define(
"dijit/nls/ca/common", ({
	buttonOk: "D'acord",
	buttonCancel: "Cancel·la",
	buttonSave: "Desa",
	itemClose: "Tanca"
})
);
