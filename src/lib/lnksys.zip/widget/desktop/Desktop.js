<@ CPrintln("-> js/modules/lnksys/widget/Desktop.js"); @>
//--------------------------------------------------------------------------------
//lnksys.widget.Desktop
//--------------------------------------------------------------------------------
define(
	[
		"dojo/_base/declare",
		"dijit/_WidgetBase",
		"dijit/_TemplatedMixin",
		"./Dock",
		"dojo/text!./template/Desktop.html",
		"xstyle/css!lnksys/widget/desktop/ui/Desktop.css"
	],
	function(
		declare,
		_WidgetBase,
		_TemplatedMixin,
		_dock,
		template,
		css
	){
		return declare(
			"lnksys.ui.Desktop",
			[
				_WidgetBase,
				_TemplatedMixin
			],
			{
				templateString: template,
				"constructor":function(){
					console.log("modules/lnksys/widget/Desktop:constructor():start")
					window.qwerqwer=this;
					console.log("modules/lnksys/widget/Desktop:constructor():end")
				},
				"postCreate":function(){
					this.dock=new _dock();
					this.dock.placeAt(this.taskbar)
				}
			}
		);
	}
);
