<@ CPrintln("-> js/modules/lnksys/widget/Dialog.js"); @>
//--------------------------------------------------------------------------------
//lnksys.widget.Dialog
//--------------------------------------------------------------------------------
define(
	[
		"dojo/_base/declare",
		"dojo/ready",
		//"./lib/jquery/jquery.js",
		"./lib/jspanel/jspanel.js",
		//"/jquery.terminal/jquery.terminal.js",
		"dijit/_WidgetBase",
		"xstyle/css!lnksys/widget/dialog/ui/Dialog.css"

	],
	function(
		declare,
		ready,
		//_jquery,
		_jspanel,
		_WidgetBase,
		css

	){
		return declare(
			"Dialog",
			[
				_WidgetBase
			],
			{
				"constructor":function(){
					console.log("modules/lnksys/widget/Dialog:constructor():start")
					this.panel=jsPanel.create({
						theme: {
							        bgPanel: '#222222',
							        bgContent: '#111111',
							        colorHeader: '#FFFFFF',
							        colorContent: '#888888'
						},
						/*
						theme:"bootstrap-dark",
						*/
						onclosed:dojo.hitch(this,function(panel,closedByUser){
							this.panel=null;
							this.destroy()
						})
					})
					console.log("modules/lnksys/widget/Dialog:constructor():end")
				},
				"destroy":function(){
					console.log("modules/lnksys/widget/Dialog:destructor():start")
					if(this.panel!=null){
						this.panel.close();
					}
					console.log("modules/lnksys/widget/Dialog:destructor():end")
				}
			}
		)
	}
);
