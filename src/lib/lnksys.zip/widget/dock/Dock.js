<@ CPrintln("-> js/modules/lnksys/widget/Dock.js"); @>
//--------------------------------------------------------------------------------
//lnksys.widget.Dock
//--------------------------------------------------------------------------------
define(
	[
		"dojo/_base/declare",
		"dojo/dom-construct",
		"dijit/_WidgetBase",
		"dijit/_TemplatedMixin",
		"./Terminal",
		"dojo/text!./template/Dock.html",
		"xstyle/css!/js/modules/lnksys/widget/dock/ui/Dock.css"
	],
	function(
		declare,
		domConstruct,
		_WidgetBase,
		_TemplatedMixin,
		terminal,
		template,
		css
	){
		return declare(
			"lnksys.ui.Dock",
			[
				_WidgetBase,
				_TemplatedMixin
			],
			{
				templateString: template,
				items:[],
				"constructor":function(){
					console.log("modules/lnksys/widget/Dock:constructor():start")
					console.log("modules/lnksys/widget/Dock:constructor():end")
				},
				"postCreate":function(){
					dojo.connect(
						this.ivk_terminal,
						"onclick",
						function(){
							var t=new Terminal();
						}
					);

				}
			}
		);
	}
);
