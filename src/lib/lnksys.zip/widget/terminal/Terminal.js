<@ CPrintln("-> js/modules/lnksys/widget/Terminal.js"); @>
//--------------------------------------------------------------------------------
//lnksys.widget.Terminal
//--------------------------------------------------------------------------------
define(
	[
		"dojo/_base/declare",
		"dojo/ready",
		//"/jquery/jquery.js",
		//"/jquery.terminal/jquery.terminal.js",
		"dijit/_WidgetBase",
		"dijit/_TemplatedMixin",
		"lnksys/lnksysui/wm",
		"lnksys/widget/Dialog",
		"xstyle/css!lnksys/widget/terminal/ui/Terminal.css",
		"dojo/text!./template/Terminal.html"
	],
	function(
		declare,
		ready,
		//_jquery,
		//_terminal,
		_WidgetBase,
		_TemplatedMixin,
		_wm,
		Dialog,
		css,
		template
	){
		return declare(
			"Terminal",
			[
				_WidgetBase,
				_TemplatedMixin
			],
			{
				templateString: template,
				constructor:function(params,srcNodeRef){
					console.log('modules/lnksys/widget/Terminal:constructor:start');
					console.log('modules/lnksys/widget/Terminal:constructor:end');
				},
				postCreate:function(){
					console.log('modules/lnksys/widget/Terminal:postCreate:start');
					console.log(this.templateString);
					console.log(this.domNode);
					console.log(jQuery.terminal);
					console.log($.terminal);
					console.log('modules/lnksys/widget/Terminal:postCreate:end');
					window.asdf=this;
					ready(dojo.hitch(this,function(){
						this.initTerminal();
					}));
				},
				initTerminal:function(){
					this.dialog=new Dialog();
					this.dialog.panel.setHeaderTitle("Terminal");
					//$(this.dialog.panel.content).css('border','1');
					/* $(this.dialog.panel.content).css('box-shadow','0px 0px 0px 8px inset rgba(255,255,255,0.2)'); */
					//$(this.domNode).terminal(
					this.term=$(this.dialog.panel.content).terminal(
						this.cmdproc,
						{
							greetings: "JS Repl",
							name:"js_demo",
							height:400,
							prompt:"js>"
						}
					);
					this.term.focus();
					$(this.dialog.panel.content).css('background','unset');
					$(this.dialog.panel).css('background','unset');
					$(this.dialog.panel.header).css('background','#222222');
				},
				cmdproc:function(command,term){
					switch(command){
						case 'help':
							term.echo('Available Commands:');
							term.echo('\thelp');
							term.echo('\t\tprint help');
							term.echo('\treload');
							term.echo('\t\treload web page');
							term.echo('\ttestcon');
							term.echo('\t\ttest connection');
							term.echo('\txas');
							term.echo('\t\tserver repl');
							break;
						case 'reload':
							window.location.reload();
							break;
						case 'testcon':
							term.echo('testing connection...');
							$.get(
								'/sjs/cmd.js'
							).done(
								function(){
									term.echo('done');
								}
							).fail(
								function(){
									term.echo('error');
								}
							);
							break;
						case 'xas':
							term.push(
								function(command,term){
									if(command=='exit'){
										term.pop();
										return;
									}else{
										console.log('asdf');
										console.warn('asdf');
										console.error('asdf');
										console.debug('asdf');
										term.pause();
										$('.cmd-cursor-line').addClass('animate');
										//term.echo(JSON.stringify({cmd:command}));
										$.ajax(
											'/sjs/cmd.js',
											{
												data:JSON.stringify({cmd:command}),
												contentType:'application/json',
												type:'POST'
											}
										).done(
											function(data){
												try{
													console.log('1');
													var obj_response=JSON.parse(data);
													if(typeof(obj_response)==='string'){
														console.log('2');
														term.echo("is string");
														term.echo(data);
													}else{
														console.log('3');
														if(Array.isArray(obj_response)){
															term.echo(JSON.stringify(obj_response));
														}else{
															if(obj_response['type']==null){
															}else{
																switch(obj_response['type']){
																	case 'text':
																		if(typeof(obj_response['data'])==='string'||obj_response['data'] instanceof String){
																			term.echo(obj_response['data']);
																		}else{
																			term.echo(JSON.stringify(obj_response['data']));
																		}
																		break;
																	case 'js':
																		if(typeof(obj_response['data'])==='string'||obj_response['data'] instanceof String){
																			try{
																				console.log('1');
																				eval(obj_response['data']);
																			}catch(e){
																				console.error(e.toString());
																			}
																			break;
																		}else{
																			term.echo('No feedback data provided');
																		}
																		default:
																			term.echo('Invalid feedback type ('+obj_response['type']+')');
																			break;
																}
															}
														}
													}
												}catch(e){
													console.log('4');
													term.echo(data);
												}
												term.resume();
												$('.cmd-cursor-line').removeClass('animate');
											}
										).fail(
											function(){
												term.echo("Error: Ajax Failure");
												term.resume();
												$('.cmd-cursor-line').removeClass('animate');
											}
										);

									}
								},
								{
									prompt: 'xas>',
									name: 'xas',
									height: 400,
									greetings:'Server commands' 
								}

							);
							break;
						case 'js':
							term.push(
								function(command,term){
									if(command=='exit'){
										term.pop();
										return;
									}else{
										term.echo(eval(command));
									}
								},
								{
									prompt: 'js>',
									name: 'js',
									height: 400,
									greetings:'Javascript REPL' 
								}
							);
							break;
						default:
							term.echo('Error: Invalid command');
							break;
					}
				},
				/* manual build
				buildRendering:function(){
					console.log('modules/lnksys/widget/Terminal:buildRendering:start');
					console.log('modules/lnksys/widget/Terminal:buildRendering:end');
				},
				*/
				destroy:function(){
					console.log('modules/lnksys/widget/Terminal:destroy:start');
					if(this.dialog!=null)this.dialog.destroy();
					console.log('modules/lnksys/widget/Terminal:destroy:end');
				}

			}
		);
	}
);
