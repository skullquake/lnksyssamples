<@ CPrintln("-> js/modules/lnksys/widget/Dialog.js"); @>
//--------------------------------------------------------------------------------
//lnksys.widget.Toast
//--------------------------------------------------------------------------------
define(
	[
		"dojo/_base/declare",
		"dojo/ready",
		//"./lib/jquery/jquery.js",
		//"./lib/jquery-toast-plugin/jquery.toast.min",
		"dijit/_WidgetBase",
		"xstyle/css!lnksys/widget/toast/lib/jquery-toast-plugin/jquery.toast.min.css"

	],
	function(
		declare,
		ready,
		//_jquery,
		//_toast,
		_WidgetBase,
		css

	){
		return declare(
			"Toast",
			[
				_WidgetBase
			],
			{
				"constructor":function(){
					console.log("modules/lnksys/widget/Dialog:constructor():start")
					//alert(_toast);
					console.log("modules/lnksys/widget/Dialog:constructor():end")
				},
				"toast":function(){
					$.toast.apply(null,arguments);
				},
				"destroy":function(){
					console.log("modules/lnksys/widget/Dialog:destructor():start")
					console.log("modules/lnksys/widget/Dialog:destructor():end")
				}
			}
		)
	}
);
